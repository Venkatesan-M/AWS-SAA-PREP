opencv_version = "4.8.1.78"
contrib = False
headless = True
rolling = False
ci_build = True