#  Copyright (c) 2022, Manfred Moitzi
#  License: MIT License
