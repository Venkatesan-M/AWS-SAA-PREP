# Copyright (c) 2011-2022, Manfred Moitzi
# License: MIT License
